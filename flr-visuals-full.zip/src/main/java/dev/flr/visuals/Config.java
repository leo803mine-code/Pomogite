package dev.flr.visuals;

/** Runtime client settings. Kept deliberately allocation-free in render/tick paths. */
public final class Config {
    public static boolean master = true;
    public static boolean halo = true;
    public static boolean wings = true;
    public static boolean cape = true;
    public static boolean aura = true;
    public static boolean trail = true;
    public static boolean hitSparks = true;
    public static boolean prettyFog = true;
    public static boolean noRenderParticles = false;

    /** Wing type: 0=Angel, 1=Demon, 2=Dark, 3=Crystal, 4=Energy. */
    public static int wingStyle = 0;
    /** Wing size multiplier. */
    public static double wingSize = 1.0;
    /** Wing flap speed multiplier. */
    public static double speed = 1.0;

    /** Auto-swap a totem into the offhand while falling. */
    public static boolean autoTotem = true;
    /** Fall distance (blocks) that triggers the swap; earlier if the landing would be lethal. */
    public static double autoTotemFall = 5.0;

    /** 0=Purple, 1=Cyan, 2=Pink, 3=Gold, 4=Green. */
    public static int theme = 0;
    public static final String[] THEME_NAMES = {"Purple", "Cyan", "Pink", "Gold", "Green"};
    public static final int[] THEME_COLORS = {0x7A4FFF, 0x2EE7FF, 0xFF50A8, 0xFFD04D, 0x5BE36A};

    /** Maximum cosmetic particles emitted by FLR in one client tick. */
    public static int particleBudget = 18;
    /** Effects are skipped beyond this distance. */
    public static double maxDistance = 48.0;

    private Config() {}

    public static int color() {
        return THEME_COLORS[Math.floorMod(theme, THEME_COLORS.length)];
    }
}
