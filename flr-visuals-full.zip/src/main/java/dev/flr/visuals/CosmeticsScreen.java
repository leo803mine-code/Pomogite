package dev.flr.visuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public final class CosmeticsScreen extends Screen {
    public CosmeticsScreen() { super(Component.literal("FLR VISUALS")); }

    @Override
    protected void init() {
        int cx = width / 2;
        int y = height / 2 - 94;
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Master: " + on(Config.master)), b -> { Config.master=!Config.master; b.setMessage(Component.literal("Master: " + on(Config.master))); }).bounds(cx-80,y,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Halo: " + on(Config.halo)), b -> { Config.halo=!Config.halo; b.setMessage(Component.literal("Halo: " + on(Config.halo))); }).bounds(cx-80,y+24,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Wings: " + on(Config.wings)), b -> { Config.wings=!Config.wings; b.setMessage(Component.literal("Wings: " + on(Config.wings))); }).bounds(cx-80,y+48,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Cape: " + on(Config.cape)), b -> { Config.cape=!Config.cape; b.setMessage(Component.literal("Cape: " + on(Config.cape))); }).bounds(cx-80,y+72,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Aura: " + on(Config.aura)), b -> { Config.aura=!Config.aura; b.setMessage(Component.literal("Aura: " + on(Config.aura))); }).bounds(cx-80,y+96,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Theme: " + Config.THEME_NAMES[Config.theme]), b -> { Config.theme=(Config.theme+1)%Config.THEME_NAMES.length; b.setMessage(Component.literal("Theme: " + Config.THEME_NAMES[Config.theme])); }).bounds(cx-80,y+120,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Wing type: " + WingModel.NAMES[Config.wingStyle]), b -> { Config.wingStyle=(Config.wingStyle+1)%WingModel.TYPES; b.setMessage(Component.literal("Wing type: " + WingModel.NAMES[Config.wingStyle])); }).bounds(cx-80,y+144,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Auto totem: " + on(Config.autoTotem)), b -> { Config.autoTotem=!Config.autoTotem; b.setMessage(Component.literal("Auto totem: " + on(Config.autoTotem))); }).bounds(cx-80,y+168,160,20).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Close"), b -> onClose()).bounds(cx-80,y+192,160,20).build());
    }

    private static String on(boolean v) { return v ? "ON" : "OFF"; }

    @Override public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        g.fill(0,0,width,height,0xD90B0B10);
        g.drawCenteredString(font, "FLR VISUALS", width/2, height/2-129, 0xFFFFFFFF);
        super.render(g, mouseX, mouseY, partialTick);
    }
}
