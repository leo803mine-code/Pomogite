package dev.flr.visuals;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.neoforged.neoforge.client.event.ClientTickEvent;

/**
 * Автосвап тотема: если игрок падает и тотема в левой руке нет - берём его из инвентаря/хотбара.
 * После приземления (если тотем не сработал) возвращаем прежний предмет в левую руку.
 */
public final class AutoTotem {

    private static final int OFFHAND_BUTTON = 40;   // кнопка 40 в ClickType.SWAP = левая рука
    private static int cooldown;
    private static int swappedMenuSlot = -1;        // слот инвентаря, откуда взяли тотем
    private static ItemStack previousOffhand = ItemStack.EMPTY;
    private static int safeTicks;

    private AutoTotem() {}

    public static void tick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.gameMode == null || mc.level == null) {
            forget();
            return;
        }
        if (!Config.autoTotem || p.isCreative() || p.isSpectator()) {
            forget();
            return;
        }
        if (cooldown > 0) {
            cooldown--;
            return;
        }
        // клики по инвентарю игрока валидны только когда открыт именно он (containerId 0), не сундук и т.п.
        if (p.containerMenu != p.inventoryMenu) return;

        if (isFalling(p)) {
            safeTicks = 0;
            if (!p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) swapIn(mc, p);
        } else if (swappedMenuSlot >= 0) {
            if (++safeTicks >= 10) restore(mc, p);   // ~0.5 сек после приземления
        }
    }

    /** Падение: в воздухе, летим вниз и либо упали уже достаточно далеко, либо удар убьёт. */
    private static boolean isFalling(LocalPlayer p) {
        if (p.onGround() || p.isFallFlying() || p.getAbilities().flying
                || p.isInWater() || p.isInLava() || p.onClimbable() || p.isPassenger()) {
            return false;
        }
        if (p.getDeltaMovement().y > -0.1) return false;
        double safe = p.getAttributeValue(Attributes.SAFE_FALL_DISTANCE);
        double predicted = p.fallDistance - safe;                  // примерный урон при ударе
        if (predicted <= 0) return false;
        return p.fallDistance >= Config.autoTotemFall || predicted >= p.getHealth() + p.getAbsorptionAmount();
    }

    private static void swapIn(Minecraft mc, LocalPlayer p) {
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            if (p.getInventory().getItem(i).is(Items.TOTEM_OF_UNDYING)) {
                idx = i;
                break;
            }
        }
        if (idx < 0) return;
        int menuSlot = idx < 9 ? 36 + idx : idx;                   // хотбар 0-8 -> слоты меню 36-44, инвентарь 9-35 -> 9-35
        previousOffhand = p.getOffhandItem().copy();
        mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, menuSlot, OFFHAND_BUTTON, ClickType.SWAP, p);
        swappedMenuSlot = menuSlot;
        cooldown = 4;
    }

    private static void restore(Minecraft mc, LocalPlayer p) {
        int slot = swappedMenuSlot;
        ItemStack inSlot = p.inventoryMenu.getSlot(slot).getItem();
        boolean totemStillThere = p.getOffhandItem().is(Items.TOTEM_OF_UNDYING);   // если тотем сработал - руки уже пусты
        boolean slotUntouched = ItemStack.isSameItemSameComponents(inSlot, previousOffhand);
        if (totemStillThere && slotUntouched) {
            mc.gameMode.handleInventoryMouseClick(p.inventoryMenu.containerId, slot, OFFHAND_BUTTON, ClickType.SWAP, p);
            cooldown = 4;
        }
        forget();
    }

    private static void forget() {
        swappedMenuSlot = -1;
        previousOffhand = ItemStack.EMPTY;
        safeTicks = 0;
    }
}
